# 도서목록 주제어 도우미

ISBN 목록을 업로드하면 알라딘 Open API로 도서 기본정보를 조회하고, 공공데이터포털의 `문화체육관광부 국립중앙도서관_주제 정보 제공 서비스`를 호출해 도서별 표준 주제어 후보를 붙이는 Streamlit 서비스입니다.

## 1. 준비물

- Python 3.10 이상 권장
- 알라딘 Open API TTBKey
- 공공데이터포털 일반 인증키(Decoding)
- 공공데이터포털 Swagger 화면에서 확인한 주제정보 API `GET 호출 URL`

API 키는 프로그램 파일에 저장하지 않고, 실행 화면에서 직접 입력합니다.

## 2. 설치

```bash
cd library_subject_service
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

macOS/Linux는 아래처럼 가상환경을 활성화합니다.

```bash
source .venv/bin/activate
```

## 3. 실행

```bash
streamlit run app.py
```

브라우저가 열리면 다음 순서로 사용합니다.

1. 알라딘 TTBKey 입력
2. 공공데이터포털 일반 인증키(Decoding) 입력
3. Swagger에서 확인한 주제정보 API 호출 URL 입력
4. 검색어 요청변수명, 페이지 요청변수명, 건수 요청변수명 확인
5. ISBN 엑셀 또는 txt/csv 업로드
6. `주제어 테스트 조회`로 먼저 API 연결 확인
7. `도서목록 주제어 생성` 실행
8. 엑셀 다운로드

## 4. ISBN 파일 형식

엑셀 파일은 `ISBN`, `ISBN13`, `ISBN(13자리)` 등 ISBN이라는 단어가 들어간 컬럼을 우선 읽습니다. 해당 컬럼이 없으면 첫 번째 컬럼에서 13자리 숫자를 찾습니다.

txt/csv 파일은 줄바꿈, 쉼표, 탭, 공백으로 구분된 13자리 ISBN을 읽습니다.

## 5. 결과 엑셀 컬럼

- ISBN(13자리)
- 서명
- 저자
- 출판사
- 출간일
- 책소개
- 분야
- 자동추출키워드
- 표준주제어_후보
- 상위어_BT
- 하위어_NT
- 관련어_RT
- 비우선어_UF
- 주제정보_원문요약

## 6. 주제정보 API 설정 팁

공공데이터포털의 Swagger UI에서 해당 API를 열고 `OpenAPI 실행 준비`를 누른 뒤 필수 요청변수를 확인합니다. 가이드에 따르면 `serviceKey`는 일반 인증키(Decoding)를 입력해야 합니다.

이 서비스는 응답 구조가 조금 달라도 동작하도록 JSON/XML을 넓게 파싱합니다. 다만 검색어 요청변수명은 실제 Swagger 명세와 같아야 합니다. 예를 들어 명세의 검색어 변수가 `keyword`, `title`, `subject`, `query`, `cond[title::LIKE]` 중 하나라면 화면에서 그 값을 정확히 입력하세요.

## 7. 한계와 권장 사용법

- 자동 추출 키워드는 간단한 규칙 기반입니다. 최종 주제어는 사서가 검토 후 확정하는 보조 도구로 사용하세요.
- 공공데이터 API 상세기능의 실제 변수명이 공개 화면에서 확인되지 않는 경우가 있어, 실행 화면에서 호출 URL과 변수명을 조정할 수 있게 만들었습니다.
- 대량 ISBN 처리 시 트래픽 제한을 피하려면 요청 간격을 0.3~1초 이상으로 두세요.
